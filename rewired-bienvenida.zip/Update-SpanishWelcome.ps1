#Requires -Version 5.1
<#
.SYNOPSIS
  Add the Spanish "bienvenida" welcome section on /es and point
  "Hablamos Espanol" hero badges to /es#bienvenida.

.DESCRIPTION
  Run from the repo root (the folder that contains src\app), or pass -Root.

  1. Inserts the welcome section (id="bienvenida") and VideoObject JSON-LD
     on src\app\es\page.tsx, just below the hero / trust bar.
  2. Updates every hero badge link that currently points at /es so it
     points at /es#bienvenida. The English homepage hero (the pathname
     ternary) is updated too. Logo, Inicio, language switchers, and
     plain-text mentions are left alone.
  3. Copies public\videos files from this script's folder into the repo
     if they are not already in place.

  Site files are read and written as UTF-8 without a BOM. Line endings
  are preserved. This script does not create backup copies; if the repo
  is a git checkout, undo with:  git checkout -- .

  Running the script a second time is safe: already-updated pages and
  videos are left alone.

.PARAMETER Root
  Repo root (the folder that contains src\app). Defaults to the current
  directory.

.PARAMETER DryRun
  Show what would change without writing files. Same as -WhatIf.

.EXAMPLE
  cd C:\Users\jsilv\rewired-ketamine
  powershell -NoProfile -ExecutionPolicy Bypass -File .\Update-SpanishWelcome.ps1 -DryRun

.EXAMPLE
  .\Update-SpanishWelcome.ps1
#>
[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [string]$Root = '.',

    [switch]$DryRun
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

if ($DryRun) {
    $WhatIfPreference = $true
}

function Read-Utf8NoBom([string]$Path) {
    $utf8 = New-Object System.Text.UTF8Encoding $false
    return [System.IO.File]::ReadAllText($Path, $utf8)
}

function Write-Utf8NoBom([string]$Path, [string]$Text) {
    $utf8 = New-Object System.Text.UTF8Encoding $false
    [System.IO.File]::WriteAllText($Path, $Text, $utf8)
}

function Get-NewLine([string]$Text) {
    if ($Text.Contains("`r`n")) { return "`r`n" }
    return "`n"
}

function ConvertFrom-Utf8Base64([string]$B64) {
    $bytes = [System.Convert]::FromBase64String($B64)
    return [System.Text.Encoding]::UTF8.GetString($bytes)
}

function ConvertTo-RepoNewlines([string]$Payload, [string]$NewLine) {
    $normalized = $Payload -replace "`r`n", "`n" -replace "`r", "`n"
    if ($NewLine -eq "`r`n") {
        return $normalized.Replace("`n", "`r`n")
    }
    return $normalized
}

function Get-RelativePath([string]$Full, [string]$Base) {
    $fullNorm = [System.IO.Path]::GetFullPath($Full)
    $baseNorm = [System.IO.Path]::GetFullPath($Base).TrimEnd('\', '/') + [System.IO.Path]::DirectorySeparatorChar
    if ($fullNorm.StartsWith($baseNorm, [System.StringComparison]::OrdinalIgnoreCase)) {
        return ($fullNorm.Substring($baseNorm.Length) -replace '\\', '/')
    }
    return ($fullNorm -replace '\\', '/')
}

# Payloads are UTF-8 (section copy and JSON-LD) stored as base64 so this
# .ps1 file can stay ASCII-only.
$script:LdBase64 = @'
CgogICAgICA8c2NyaXB0CiAgICAgICAgdHlwZT0iYXBwbGljYXRpb24vbGQranNvbiIKICAgICAgICBkYW5nZXJvdXNseVNldElubmVySFRNTD17ewogICAgICAgICAgX19odG1sOiBKU09OLnN0cmluZ2lmeSh7CiAgICAgICAgICAgICJAY29udGV4dCI6ICJodHRwczovL3NjaGVtYS5vcmciLAogICAgICAgICAgICAiQHR5cGUiOiAiVmlkZW9PYmplY3QiLAogICAgICAgICAgICAibmFtZSI6ICJIYWJsYW1vcyBlc3Bhw7FvbC4gRGUgdmVyZGFkLiB8IERyLiBKYWNvYiBTaWx2ZXJzdG9uZSIsCiAgICAgICAgICAgICJkZXNjcmlwdGlvbiI6ICJFbCBEci4gSmFjb2IgU2lsdmVyc3RvbmUsIGRlIE3DqXhpY28sIGRhIGxhIGJpZW52ZW5pZGEgZW4gZXNwYcOxb2wgYSBxdWllbmVzIGJ1c2NhbiBjdWlkYWRvIGVuIFJld2lyZWQgS2V0YW1pbmUgZW4gQXZlbnR1cmEuIE5vIGVzIHVuYSB0cmFkdWNjacOzbjogZXMgY8OzbW8gcGVuc2Ftb3MsIGPDs21vIHNlbnRpbW9zIHkgY8OzbW8gY3VpZGFtb3MgYSBudWVzdHJhcyBmYW1pbGlhcy4iLAogICAgICAgICAgICAidGh1bWJuYWlsVXJsIjogImh0dHBzOi8vd3d3LnJld2lyZWRrZXRhbWluZS5jb20vdmlkZW9zL2JpZW52ZW5pZGEtcG9zdGVyLmpwZyIsCiAgICAgICAgICAgICJ1cGxvYWREYXRlIjogIjIwMjYtMTEtMjMiLAogICAgICAgICAgICAiY29udGVudFVybCI6ICJodHRwczovL3d3dy5yZXdpcmVka2V0YW1pbmUuY29tL3ZpZGVvcy9iaWVudmVuaWRhLWRyLXNpbHZlcnN0b25lLm1wNCIsCiAgICAgICAgICAgICJkdXJhdGlvbiI6ICJQVDMxUyIsCiAgICAgICAgICAgICJpbkxhbmd1YWdlIjogImVzIgogICAgICAgICAgfSkKICAgICAgICB9fQogICAgICAvPgo=
'@

$script:SectionBase64 = @'
ICAgICAgey8qIEJJRU5WRU5JREEgKi99CiAgICAgIDxzZWN0aW9uIGlkPSJiaWVudmVuaWRhIiBhcmlhLWxhYmVsbGVkYnk9ImJpZW52ZW5pZGEtaGVhZGluZyIgY2xhc3NOYW1lPSJzY3JvbGwtbXQtMjQgcHktMTYgbWQ6cHktMjQgcHgtNiBiZy13aGl0ZSI+CiAgICAgICAgPGRpdiBjbGFzc05hbWU9Im1heC13LTZ4bCBteC1hdXRvIGdyaWQgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTEwIGxnOmdhcC0xNiBpdGVtcy1jZW50ZXIiPgogICAgICAgICAgPGRpdiBjbGFzc05hbWU9InctZnVsbCBtYXgtdy1bMzIwcHhdIG14LWF1dG8iPgogICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0icm91bmRlZC0yeGwgc2hhZG93LXhsIG92ZXJmbG93LWhpZGRlbiBiZy1bIzBCMUQzNl0iPgogICAgICAgICAgICAgIDx2aWRlbwogICAgICAgICAgICAgICAgY29udHJvbHMKICAgICAgICAgICAgICAgIHBsYXlzSW5saW5lCiAgICAgICAgICAgICAgICBwcmVsb2FkPSJtZXRhZGF0YSIKICAgICAgICAgICAgICAgIHBvc3Rlcj0iL3ZpZGVvcy9iaWVudmVuaWRhLXBvc3Rlci5qcGciCiAgICAgICAgICAgICAgICB3aWR0aD17NzIwfQogICAgICAgICAgICAgICAgaGVpZ2h0PXsxMjgwfQogICAgICAgICAgICAgICAgY2xhc3NOYW1lPSJ3LWZ1bGwgaC1hdXRvIGJsb2NrIgogICAgICAgICAgICAgICAgdGl0bGU9Ik1lbnNhamUgZGVsIERyLiBKYWNvYiBTaWx2ZXJzdG9uZTogSGFibGFtb3MgZXNwYcOxb2wsIGRlIHZlcmRhZC4iCiAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPSJWaWRlbyBkZSBiaWVudmVuaWRhIGRlbCBEci4gSmFjb2IgU2lsdmVyc3RvbmUsIGVuIGVzcGHDsW9sLiIKICAgICAgICAgICAgICA+CiAgICAgICAgICAgICAgICA8c291cmNlIHNyYz0iL3ZpZGVvcy9iaWVudmVuaWRhLWRyLXNpbHZlcnN0b25lLm1wNCIgdHlwZT0idmlkZW8vbXA0IiAvPgogICAgICAgICAgICAgICAgU3UgbmF2ZWdhZG9yIG5vIHB1ZWRlIHJlcHJvZHVjaXIgZXN0ZSB2aWRlby4gUHVlZGUgZGVzY2FyZ2FybG8gZW57IiAifQogICAgICAgICAgICAgICAgPGEgaHJlZj0iL3ZpZGVvcy9iaWVudmVuaWRhLWRyLXNpbHZlcnN0b25lLm1wNCIgY2xhc3NOYW1lPSJ1bmRlcmxpbmUiPmVzdGUgZW5sYWNlPC9hPi4KICAgICAgICAgICAgICA8L3ZpZGVvPgogICAgICAgICAgICA8L2Rpdj4KICAgICAgICAgICAgPGRldGFpbHMgY2xhc3NOYW1lPSJtdC00IHRleHQtc20gdGV4dC1bIzU1NV0iPgogICAgICAgICAgICAgIDxzdW1tYXJ5IGNsYXNzTmFtZT0iY3Vyc29yLXBvaW50ZXIgZm9udC1zZW1pYm9sZCB0ZXh0LVsjMEIxRDM2XSBob3Zlcjp0ZXh0LVsjQzlBNjZCXSI+VHJhbnNjcmlwY2nDs24gZGVsIHZpZGVvPC9zdW1tYXJ5PgogICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT0ibXQtMyBsZWFkaW5nLXJlbGF4ZWQiPgogICAgICAgICAgICAgICAgSG9sYSwgc295IGVsIERyLiBKYWNvYiBTaWx2ZXJzdG9uZS4gU295IGRlIE3DqXhpY28sIHkgY3VhbmRvIGxlIGRlY2ltb3MgJnF1b3Q7aGFibGFtb3MgZXNwYcOxb2wmcXVvdDssIGxvIGRlY2ltb3MgZW4gc2VyaW8uIE5vIGVzIHVuYSB0cmFkdWNjacOzbi4gRXMgY8OzbW8gcGVuc2Ftb3MsIGPDs21vIHNlbnRpbW9zLCB5IGPDs21vIGN1aWRhbW9zIGEgbnVlc3RyYXMgZmFtaWxpYXMuIFPDqSBsbyBkaWbDrWNpbCBxdWUgcHVlZGUgc2VyIGhhYmxhciBkZSBsYSBzYWx1ZCBtZW50YWwgZW4gbnVlc3RyYSBjb211bmlkYWQuIEFxdcOtLCB1c3RlZCBubyB0aWVuZSBxdWUgZXhwbGljYXJzZSBkb3MgdmVjZXMuIERlc2RlIHN1IHByaW1lcmEgbGxhbWFkYSBoYXN0YSBzdSBzZWd1aW1pZW50bywgbG8gYXRlbmRlbW9zIGVuIHN1IGlkaW9tYSwgY29uIHJlc3BldG8geSBjb24gY29yYXrDs24uIEVzdGFtb3MgYXF1w60gcGFyYSB1c3RlZC4gSGFibGVtb3MuCiAgICAgICAgICAgICAgPC9wPgogICAgICAgICAgICA8L2RldGFpbHM+CiAgICAgICAgICA8L2Rpdj4KCiAgICAgICAgICA8ZGl2PgogICAgICAgICAgICA8cCBjbGFzc05hbWU9InRleHQtc20gdHJhY2tpbmctd2lkZXN0IHRleHQtWyNDOUE2NkJdIGZvbnQtc2VtaWJvbGQgbWItMyI+VU4gTUVOU0FKRSBERUwgRFIuIFNJTFZFUlNUT05FPC9wPgogICAgICAgICAgICA8aDIgaWQ9ImJpZW52ZW5pZGEtaGVhZGluZyIgY2xhc3NOYW1lPSJmb250LXNlcmlmIHRleHQtM3hsIG1kOnRleHQtNHhsIGxnOnRleHQtNXhsIGZvbnQtYm9sZCB0ZXh0LVsjMEIxRDM2XSBtYi02Ij4KICAgICAgICAgICAgICBIYWJsYW1vcyBlc3Bhw7FvbC4gRGUgdmVyZGFkLgogICAgICAgICAgICA8L2gyPgogICAgICAgICAgICA8cCBjbGFzc05hbWU9InRleHQtbGcgdGV4dC1bIzQ0NF0gbGVhZGluZy1yZWxheGVkIG1iLTIiPgogICAgICAgICAgICAgIFNveSBkZSBNw6l4aWNvLiBDdWFuZG8gbGUgZGVjaW1vcyBxdWUgaGFibGFtb3MgZXNwYcOxb2wsIGxvIGRlY2ltb3MgZW4gc2VyaW8uCiAgICAgICAgICAgIDwvcD4KICAgICAgICAgICAgPHAgY2xhc3NOYW1lPSJ0ZXh0LVsjMEIxRDM2XSBmb250LXNlbWlib2xkIG1iLTgiPuKAlCBEci4gSmFjb2IgU2lsdmVyc3RvbmU8L3A+CiAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9InNwYWNlLXktNSBtYi0xMCI+CiAgICAgICAgICAgICAgPGxpIGNsYXNzTmFtZT0iYm9yZGVyLWwtMiBib3JkZXItWyNDOUE2NkJdIHBsLTQiPgogICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPSJmb250LXNlbWlib2xkIHRleHQtWyMwQjFEMzZdIj5ObyBlcyB1bmEgdHJhZHVjY2nDs24uPC9wPgogICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPSJ0ZXh0LVsjNTU1XSI+RXMgY8OzbW8gcGVuc2Ftb3MsIGPDs21vIHNlbnRpbW9zIHkgY8OzbW8gY3VpZGFtb3MgYSBudWVzdHJhcyBmYW1pbGlhcy48L3A+CiAgICAgICAgICAgICAgPC9saT4KICAgICAgICAgICAgICA8bGkgY2xhc3NOYW1lPSJib3JkZXItbC0yIGJvcmRlci1bI0M5QTY2Ql0gcGwtNCI+CiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9ImZvbnQtc2VtaWJvbGQgdGV4dC1bIzBCMUQzNl0iPlVzdGVkIG5vIHRpZW5lIHF1ZSBleHBsaWNhcnNlIGRvcyB2ZWNlcy48L3A+CiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9InRleHQtWyM1NTVdIj5Tw6kgbG8gZGlmw61jaWwgcXVlIHB1ZWRlIHNlciBoYWJsYXIgZGUgbGEgc2FsdWQgbWVudGFsIGVuIG51ZXN0cmEgY29tdW5pZGFkLjwvcD4KICAgICAgICAgICAgICA8L2xpPgogICAgICAgICAgICAgIDxsaSBjbGFzc05hbWU9ImJvcmRlci1sLTIgYm9yZGVyLVsjQzlBNjZCXSBwbC00Ij4KICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT0iZm9udC1zZW1pYm9sZCB0ZXh0LVsjMEIxRDM2XSI+RW4gc3UgaWRpb21hLCBkZSBsYSBwcmltZXJhIGxsYW1hZGEgYWwgc2VndWltaWVudG8uPC9wPgogICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPSJ0ZXh0LVsjNTU1XSI+TG8gYXRlbmRlbW9zIGNvbiByZXNwZXRvIHkgY29uIGNvcmF6w7NuLjwvcD4KICAgICAgICAgICAgICA8L2xpPgogICAgICAgICAgICA8L3VsPgogICAgICAgICAgICA8TGluayBocmVmPSIjY29udGFjdCIgY2xhc3NOYW1lPSJpbmxpbmUtYmxvY2sgYmctWyNDOUE2NkJdIHRleHQtWyMwQjFEMzZdIGZvbnQtc2VtaWJvbGQgcHgtOCBweS00IHJvdW5kZWQtbGcgaG92ZXI6YmctWyNiODk1NWVdIHRyYW5zaXRpb24gdGV4dC1sZyI+CiAgICAgICAgICAgICAgSGFibGVtb3MKICAgICAgICAgICAgPC9MaW5rPgogICAgICAgICAgPC9kaXY+CiAgICAgICAgPC9kaXY+CiAgICAgIDwvc2VjdGlvbj4KCg==
'@


function Replace-Once([string]$Text, [string]$Needle, [string]$Replacement) {
    $idx = $Text.IndexOf($Needle, [System.StringComparison]::Ordinal)
    if ($idx -lt 0) { return $Text }
    return $Text.Substring(0, $idx) + $Replacement + $Text.Substring($idx + $Needle.Length)
}

function Get-RepoRoot([string]$RootPath) {
    $resolved = (Resolve-Path -LiteralPath $RootPath).Path
    $candidates = @(
        $resolved,
        (Join-Path $resolved 'rewired-ketamine')
    )
    foreach ($c in $candidates) {
        if (Test-Path -LiteralPath (Join-Path $c 'src\app\es\page.tsx')) {
            return (Resolve-Path -LiteralPath $c).Path
        }
        if (Test-Path -LiteralPath (Join-Path $c 'src\app')) {
            return (Resolve-Path -LiteralPath $c).Path
        }
    }
    return $null
}

function Update-SpanishHome([string]$Text) {
    $changes = New-Object System.Collections.Generic.List[string]
    $nl = Get-NewLine $Text
    $ld = ConvertTo-RepoNewlines (ConvertFrom-Utf8Base64 $script:LdBase64) $nl
    $sec = ConvertTo-RepoNewlines (ConvertFrom-Utf8Base64 $script:SectionBase64) $nl

    if ($Text -notmatch 'id="bienvenida"' -and $Text -notmatch '"@type": "VideoObject"') {
        $headerNeedle = $nl + $nl + '      <SiteHeaderEs />'
        if ($Text.Contains($headerNeedle) -and -not $ld.Contains('<SiteHeaderEs')) {
            $Text = Replace-Once $Text $headerNeedle ($ld + $nl + '      <SiteHeaderEs />')
            $changes.Add('inserted VideoObject JSON-LD')
        } elseif ($Text -notmatch '"@type": "VideoObject"') {
            throw 'Could not find the SiteHeaderEs insert point on src/app/es/page.tsx.'
        }
    }

    if ($Text -notmatch 'id="bienvenida"') {
        $reviewsNeedle = '      {/* Google Reviews */}'
        if ($Text.Contains($reviewsNeedle)) {
            $Text = Replace-Once $Text $reviewsNeedle ($sec + $reviewsNeedle)
            $changes.Add('inserted #bienvenida section')
        } else {
            throw 'Could not find the Google Reviews insert point on src/app/es/page.tsx.'
        }
    }

    return @{ Text = $Text; Changes = $changes }
}

function Update-BadgeLinks([string]$Text) {
    $changes = New-Object System.Collections.Generic.List[string]
    $rx = New-Object System.Text.RegularExpressions.Regex(
        'href="/es"(?=[^>]*>[^<]*Hablamos)',
        [System.Text.RegularExpressions.RegexOptions]::CultureInvariant
    )
    $badgeCount = $rx.Matches($Text).Count
    if ($badgeCount -gt 0) {
        $Text = $rx.Replace($Text, 'href="/es#bienvenida"')
        $label = if ($badgeCount -eq 1) { '1 hero badge -> /es#bienvenida' } else { "$badgeCount hero badges -> /es#bienvenida" }
        $changes.Add($label)
    }

    $homeOld = 'pathname === "/" ? "/es" :'
    $homeNew = 'pathname === "/" ? "/es#bienvenida" :'
    $homeCount = 0
    if ($Text.Contains($homeOld)) {
        $Text = $Text.Replace($homeOld, $homeNew)
        $changes.Add('English homepage hero -> /es#bienvenida')
        $homeCount = 1
    }

    return @{
        Text       = $Text
        Changes    = $changes
        BadgeCount = $badgeCount
        HomeCount  = $homeCount
    }
}

# --- Main ------------------------------------------------------------------

Write-Host "Update-SpanishWelcome"
if ($WhatIfPreference) {
    Write-Host "  [DRY RUN (no files written)]"
} else {
    Write-Host "  Changed files can be undone with:  git checkout -- ."
}
Write-Host ""

$repo = Get-RepoRoot $Root
if (-not $repo) {
    throw "Could not find src\app under '$Root'. Run this from the repo root (the folder that contains src\app), or pass -Root."
}

Write-Host "Repo: $repo"
Write-Host ""

$videoNames = @(
    'bienvenida-dr-silverstone.mp4',
    'bienvenida-poster.jpg',
    'bienvenida-poster.webp'
)
$scriptVideos = Join-Path $PSScriptRoot 'public\videos'
$destVideos = Join-Path $repo 'public\videos'
$videoWouldCopy = New-Object System.Collections.Generic.List[string]
$videoAlready = New-Object System.Collections.Generic.List[string]
$videoMissing = New-Object System.Collections.Generic.List[string]

foreach ($name in $videoNames) {
    $src = Join-Path $scriptVideos $name
    $dst = Join-Path $destVideos $name
    $srcOk = Test-Path -LiteralPath $src
    $dstOk = Test-Path -LiteralPath $dst
    if ($srcOk) {
        $same = $false
        if ($dstOk) {
            $srcItem = Get-Item -LiteralPath $src
            $dstItem = Get-Item -LiteralPath $dst
            $same = ($srcItem.Length -eq $dstItem.Length)
        }
        if ($same) {
            [void]$videoAlready.Add(('public/videos/' + $name))
        } else {
            [void]$videoWouldCopy.Add(('public/videos/' + $name))
        }
    } elseif ($dstOk) {
        [void]$videoAlready.Add(('public/videos/' + $name + ' (already in repo)'))
    } else {
        [void]$videoMissing.Add(('public/videos/' + $name))
    }
}

if ($videoWouldCopy.Count -gt 0) {
    if (-not (Test-Path -LiteralPath $destVideos)) {
        if ($WhatIfPreference) {
            Write-Host "Would create: public/videos/"
        } else {
            New-Item -ItemType Directory -Path $destVideos | Out-Null
            Write-Host "Created: public/videos/"
        }
    }
    foreach ($rel in $videoWouldCopy) {
        $name = Split-Path $rel -Leaf
        $src = Join-Path $scriptVideos $name
        $dst = Join-Path $destVideos $name
        if ($WhatIfPreference) {
            Write-Host "Would copy: $rel"
        } else {
            Copy-Item -LiteralPath $src -Destination $dst -Force
            Write-Host "Copied: $rel"
        }
    }
}
if ($videoAlready.Count -gt 0) {
    Write-Host "Videos already in place:"
    foreach ($rel in $videoAlready) { Write-Host "  $rel" }
}
if ($videoMissing.Count -gt 0) {
    Write-Host "WARNING: missing video files (extract the zip into the repo root first):"
    foreach ($rel in $videoMissing) { Write-Host "  $rel" }
}
Write-Host ""

$changed = New-Object System.Collections.Generic.List[string]
$badgeTotal = 0
$homeTotal = 0

# Spanish homepage first, so section + badge updates are reported together.
$esPage = Join-Path $repo 'src\app\es\page.tsx'
if (-not (Test-Path -LiteralPath $esPage)) {
    throw "Missing src\app\es\page.tsx under $repo"
}

$tsxFiles = Get-ChildItem -LiteralPath (Join-Path $repo 'src') -Filter *.tsx -Recurse -File |
    Where-Object { $_.FullName -notmatch '[\\/]node_modules[\\/]' }

foreach ($file in $tsxFiles) {
    $original = Read-Utf8NoBom $file.FullName
    $text = $original
    $fileChanges = New-Object System.Collections.Generic.List[string]

    $isEsHome = ([System.IO.Path]::GetFullPath($file.FullName)).Equals(
        [System.IO.Path]::GetFullPath($esPage),
        [System.StringComparison]::OrdinalIgnoreCase)
    if ($isEsHome) {
        $homeResult = Update-SpanishHome $text
        $text = $homeResult.Text
        foreach ($c in $homeResult.Changes) { [void]$fileChanges.Add($c) }
    }

    $badgeResult = Update-BadgeLinks $text
    $text = $badgeResult.Text
    foreach ($c in $badgeResult.Changes) { [void]$fileChanges.Add($c) }
    $badgeTotal += $badgeResult.BadgeCount
    $homeTotal += $badgeResult.HomeCount

    if ($text -eq $original) { continue }

    $rel = Get-RelativePath $file.FullName $repo
    $summary = ($fileChanges -join '; ')
    if ($WhatIfPreference) {
        Write-Host ("Would change: {0}  ({1})" -f $rel, $summary)
    } else {
        Write-Utf8NoBom $file.FullName $text
        Write-Host ("Changed: {0}  ({1})" -f $rel, $summary)
    }
    [void]$changed.Add($rel)
}

Write-Host ""
if ($changed.Count -eq 0 -and $videoWouldCopy.Count -eq 0) {
    Write-Host "Nothing to change. Everything is already up to date."
} else {
    $verb = if ($WhatIfPreference) { 'Would change' } else { 'Changed' }
    Write-Host ("{0} {1} file(s)." -f $verb, $changed.Count)
    Write-Host ("  Hero badges pointed at /es#bienvenida: {0}" -f $badgeTotal)
    Write-Host ("  English homepage hero updated:        {0}" -f $homeTotal)
}
Write-Host ""
Write-Host "Done."
