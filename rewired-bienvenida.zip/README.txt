Update-SpanishWelcome
=====================

What this does
--------------
Adds a welcome section on the Spanish homepage (https://www.rewiredketamine.com/es#bienvenida)
with Dr. Silverstone's video, and points every "Hablamos Espanol" hero badge
to that section. The English homepage hero is updated too.

The zip also contains the compressed video and poster images under
public\videos\. Extracting the zip into your repo root puts those files
in the right place. The script will copy them if needed.


How to run it (one command at a time)
-------------------------------------
1. Copy rewired-bienvenida.zip into your repo root, then open PowerShell:

     cd C:\Users\jsilv\rewired-ketamine

2. Extract the zip into the repo root (this adds the script, this README,
   and public\videos\):

     Expand-Archive -Force -Path .\rewired-bienvenida.zip -DestinationPath .

3. Preview (no files are edited; you should see about 115 files, including
   src\app\es\page.tsx and the hero badges):

     powershell -NoProfile -ExecutionPolicy Bypass -File .\Update-SpanishWelcome.ps1 -DryRun

   If it says "Nothing to change," the files are already updated.

4. Apply the changes:

     powershell -NoProfile -ExecutionPolicy Bypass -File .\Update-SpanishWelcome.ps1

5. Remove the script and this README so they are not committed:

     Remove-Item .\Update-SpanishWelcome.ps1, .\README.txt

6. Commit and push:

     git add -A

     git commit -m "Spanish welcome video on /es#bienvenida"

     git push

If PowerShell blocks the script, this is enough for the current window:

     Set-ExecutionPolicy -Scope Process Bypass

Undo in a git checkout with:  git checkout -- .


What changes
------------
- src\app\es\page.tsx: welcome section (id=bienvenida, scroll-margin for the
  sticky header), VideoObject JSON-LD, and the homepage badge now points
  at /es#bienvenida.
- Hero badge links on English and Spanish pages that used to go to /es
  now go to /es#bienvenida. Logo, Inicio, language switchers, and
  plain-text "Hablamos Espanol" mentions are left alone.
- public\videos\bienvenida-dr-silverstone.mp4 (H.264, 720x1280, ~6.5 MB)
- public\videos\bienvenida-poster.jpg and bienvenida-poster.webp

The script is safe to run twice. After Vercel finishes deploying, the
Hablamos Espanol badges should land on the video section.
